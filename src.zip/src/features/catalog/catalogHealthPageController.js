import { appState } from '../../app/state.js'
import {
  clearVendorDataCache,
  ensureGameCatalog,
  ensureVendorData,
  resetCatalogData,
  setVendorDataOverride,
} from '../../app/dataLoaders.js'
import { saveUserProfile } from '../../services/profile.js'
import { renderCatalogHealthPage } from './catalogHealth.js'
import {
  connectVendorImportPanel,
  renderVendorImportPanel,
} from '../vendors/vendorImport.js'

async function saveVendorImport(vendorImport) {
  if (!appState.activeUser || !appState.activeProfile) {
    window.alert('Sign in with GitHub before importing vendor files.')
    return
  }

  const nextSettings = {
    ...(appState.activeProfile.app_settings ?? {}),
    vendor_import: vendorImport,
  }

  const savedProfile = await saveUserProfile(
    appState.activeUser.id,
    { app_settings: nextSettings },
  )

  appState.activeProfile = savedProfile
  setVendorDataOverride(vendorImport)
}

async function clearVendorImport() {
  if (!appState.activeUser || !appState.activeProfile) return

  const nextSettings = {
    ...(appState.activeProfile.app_settings ?? {}),
  }

  delete nextSettings.vendor_import

  const savedProfile = await saveUserProfile(
    appState.activeUser.id,
    { app_settings: nextSettings },
  )

  appState.activeProfile = savedProfile
  clearVendorDataCache()
}

export async function openSettingsPage() {
  const mainContent = document.querySelector('.main-content')

  mainContent.innerHTML = `
    <section class="feature-page">
      <div class="panel empty-state">
        <strong>Loading application settings…</strong>
      </div>
    </section>
  `

  try {
    const [catalog, vendorData] = await Promise.all([
      ensureGameCatalog(),
      ensureVendorData(),
    ])

    if (!catalog) {
      throw new Error('The generated catalog could not be loaded.')
    }

    mainContent.innerHTML = renderCatalogHealthPage(catalog)

    document
      .querySelector('.catalog-health-page')
      ?.insertAdjacentHTML(
        'beforeend',
        renderVendorImportPanel(vendorData),
      )

    connectVendorImportPanel({
      onImport: async (vendorImport) => {
        await saveVendorImport(vendorImport)
        await openSettingsPage()
      },
      onClear: async () => {
        await clearVendorImport()
        await openSettingsPage()
      },
    })

    document
      .querySelector('#refresh-catalog-health')
      ?.addEventListener('click', async () => {
        const button = document.querySelector(
          '#refresh-catalog-health',
        )

        if (button) {
          button.disabled = true
          button.textContent = 'Refreshing…'
        }

        resetCatalogData()
        await openSettingsPage()
      })
  } catch (error) {
    console.error(error)

    mainContent.innerHTML = `
      <section class="feature-page">
        <div class="panel empty-state">
          <strong>Could not load settings</strong>
          <p>${error.message}</p>
        </div>
      </section>
    `
  }
}
